const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs-extra');

// POST /api/admin/migrate-to-v180
router.post('/migrate-to-v180', async (req, res) => {
  // Auth check
  if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'owner')) {
    return res.status(403).json({ error: 'Admin access required' });
  }

  try {
    const homeDir = process.env.HOME || '/root';
    const v180InstallDir = path.join(homeDir, 'astrowax-v180');
    const v1PanelDir = path.join(homeDir, 'AstroWax-Panel', 'panel');
    const currentDir = process.cwd();

    // 1. Backup v1.0 data
    const backupDir = path.join(homeDir, 'astrowax-v1-backup-' + Date.now());
    await fs.ensureDir(backupDir);

    const v1Data = path.join(currentDir, 'data');
    if (await fs.pathExists(v1Data)) {
      await fs.copy(v1Data, path.join(backupDir, 'data'));
    }
    const v1Config = path.join(currentDir, 'config.json');
    if (await fs.pathExists(v1Config)) {
      await fs.copy(v1Config, path.join(backupDir, 'config.json'));
    }
    const v1Env = path.join(currentDir, '.env');
    if (await fs.pathExists(v1Env)) {
      await fs.copy(v1Env, path.join(backupDir, '.env'));
    }

    // 2. Run install script for v1.80
    const installCmd = `
      set -e
      export DEBIAN_FRONTEND=noninteractive
      cd ${homeDir}
      rm -rf astrowax-v180
      curl -fsSL https://github.com/AstroVoidHostDev/astrowax/raw/main/panel.zip -o /tmp/awp-v180.zip
      mkdir -p astrowax-v180
      unzip -o /tmp/awp-v180.zip -d astrowax-v180
      cd astrowax-v180/panel/astrowax-panel

      # Copy preserved data
      mkdir -p .data
      if [ -d "${backupDir}/data" ]; then cp -r "${backupDir}/data/"* .data/ 2>/dev/null || true; fi
      if [ -f "${backupDir}/.env" ]; then cp "${backupDir}/.env" .env; fi

      # Install Node 20 + deps
      export NVM_DIR="$HOME/.nvm"
      [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
      [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
      nvm install 20 >/dev/null 2>&1 || true
      nvm use 20 >/dev/null 2>&1 || true

      echo "legacy-peer-deps=true" > .npmrc
      npm install --legacy-peer-deps --no-audit --no-fund >/dev/null 2>&1
      npm run build >/dev/null 2>&1
    `;

    exec(installCmd, { timeout: 600000, maxBuffer: 20 * 1024 * 1024 }, async (err, stdout, stderr) => {
      if (err) {
        console.error('Migration install error:', stderr);
        return res.status(500).json({
          error: 'Installation failed',
          details: stderr || err.message
        });
      }

      // 3. Stop v1.0 panel
      const stopCmd = `pm2 delete astrowax-v1-panel 2>/dev/null || true; pkill -f "node .*AstroWax-Panel" || true`;
      exec(stopCmd, () => {
        // 4. Start v1.80
        const startCmd = `
          cd ${v180InstallDir}/panel/astrowax-panel
          export NVM_DIR="$HOME/.nvm"
          [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
          [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
          nvm use 20 >/dev/null 2>&1 || true

          cat > ecosystem.config.cjs << 'EOFPM2'
module.exports = {
  apps: [{
    name: "astrowax-main",
    script: "npm",
    args: "start",
    instances: 1,
    autorestart: true,
    env: { NODE_ENV: "production", PORT: 6767 }
  }]
};
EOFPM2

          pm2 delete astrowax-main 2>/dev/null || true
          pm2 start ecosystem.config.cjs
          pm2 save
        `;

        exec(startCmd, { timeout: 60000 }, async (err2, stdout2) => {
          if (err2) {
            return res.status(500).json({
              error: 'Failed to start v1.80',
              details: err2.message
            });
          }

          // 5. Optionally delete v1.0 files
          try {
            await fs.remove(v1PanelDir);
            await fs.remove(path.join(homeDir, 'AstroWax-Panel'));
          } catch (e) {
            console.warn('Could not delete v1.0 files:', e.message);
          }

          return res.json({
            success: true,
            message: 'Migrated to v1.80',
            v180Port: 6767,
            backupDir: backupDir
          });
        });
      });
    });

  } catch (err) {
    console.error('Migration error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;