/*
 *  AstroWax Panel — Migration Route (v1.0 → v1.80)
 *  (c) 2026 ITZ_YTANSH
 */

const express = require("express");
const router = express.Router();
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs-extra");
const os = require("os");
const log = new (require("cat-loggr"))();

// ═══════════════════════════════════════════════════════════════
//  POST /api/admin/migrate-to-v180
//  Backs up v1.0, installs v1.80, starts it, deletes v1.0
// ═══════════════════════════════════════════════════════════════
router.post("/migrate-to-v180", async (req, res) => {
  const user = req.user || req.session?.user;

  // Admin-only
  if (!user || (user.role !== "admin" && user.role !== "owner")) {
    return res.status(403).json({ error: "Admin access required" });
  }

  const HOME = os.homedir();
  const v180Dir = path.join(HOME, "astrowax-v180");
  const v180PanelDir = path.join(v180Dir, "panel", "astrowax-panel");
  const v1PanelDir = process.cwd();
  const backupDir = path.join(HOME, "astrowax-v1-backup-" + Date.now());

  log.info(`[migrate] Starting v1.0 → v1.80`);
  log.info(`[migrate] From: ${v1PanelDir}`);
  log.info(`[migrate] To:   ${v180PanelDir}`);

  try {
    // ─── STEP 1: Backup ───
    await fs.ensureDir(backupDir);
    const itemsToBackup = [
      "data",
      "config.json",
      ".env",
      "storage",
      "database.sqlite",
      "users.json",
    ];
    for (const item of itemsToBackup) {
      const src = path.join(v1PanelDir, item);
      if (await fs.pathExists(src)) {
        await fs.copy(src, path.join(backupDir, item));
        log.info(`[migrate] Backed up: ${item}`);
      }
    }

    // ─── STEP 2: Install v1.80 ───
    const installCmd = `
      set -e
      export DEBIAN_FRONTEND=noninteractive

      # Node 20
      export NVM_DIR="\${HOME}/.nvm"
      [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
      [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
      command -v nvm >/dev/null 2>&1 || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
      [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
      nvm install 20 >/dev/null 2>&1 || true
      nvm use 20 >/dev/null 2>&1 || true

      # Prep dir
      rm -rf "${v180Dir}"
      mkdir -p "${v180Dir}"
      cd "${v180Dir}"

      # Download v1.80
      curl -fsSL "https://github.com/AstroVoidHostDev/astrowax/raw/main/panel.zip" -o panel.zip
      unzip -oq panel.zip
      rm -f panel.zip

      # Find panel dir
      if [ -d "${v180PanelDir}" ]; then
        cd "${v180PanelDir}"
      elif [ -d "${v180Dir}/panel" ]; then
        cd "${v180Dir}/panel"
      else
        echo "PANEL_DIR_NOT_FOUND"
        exit 1
      fi

      # Restore data
      mkdir -p .data
      [ -d "${backupDir}/data" ] && cp -r "${backupDir}/data/"* .data/ 2>/dev/null || true
      [ -f "${backupDir}/users.json" ] && cp "${backupDir}/users.json" .data/users.json 2>/dev/null || true
      [ -f "${backupDir}/database.sqlite" ] && cp "${backupDir}/database.sqlite" .data/database.sqlite 2>/dev/null || true
      [ -f "${backupDir}/.env" ] && cp "${backupDir}/.env" .env

      # Ensure .env
      [ -f .env ] || echo "PORT=6767" > .env
      grep -q "^PORT=" .env || echo "PORT=6767" >> .env
      grep -q "^JWT_SECRET=" .env || echo "JWT_SECRET=\$(head -c 32 /dev/urandom | base64)" >> .env

      # Install
      echo "legacy-peer-deps=true" > .npmrc
      rm -rf node_modules package-lock.json
      npm cache clean --force >/dev/null 2>&1 || true
      npm install --legacy-peer-deps --no-audit --no-fund >/dev/null 2>&1

      # Build
      NODE_OPTIONS="--max-old-space-size=2048" npm run build >/dev/null 2>&1

      [ -f dist/server.cjs ] || { echo "BUILD_FAILED"; exit 1; }
      echo "INSTALL_OK"
    `;

    exec(installCmd, { timeout: 600000, maxBuffer: 50 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err || !stdout.includes("INSTALL_OK")) {
        log.error("[migrate] Install failed:", stderr || err?.message);
        return res.status(500).json({
          error: "Installation failed",
          details: (stderr || err?.message || stdout || "").slice(-500),
        });
      }

      log.info("[migrate] v1.80 installed");

      // ─── Respond FIRST, then swap ───
      res.json({
        success: true,
        message: "Migration complete. Restarting panel...",
        v180Dir: v180PanelDir,
        backupDir,
      });

      // ─── Swap processes after response ───
      setTimeout(() => {
        const swapCmd = `
          # Kill v1.0
          pkill -f "node .*AstroWax-Panel" 2>/dev/null || true
          sleep 1

          # Go to v1.80
          cd "${v180PanelDir}"

          # Node 20
          export NVM_DIR="\${HOME}/.nvm"
          [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
          [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
          nvm use 20 >/dev/null 2>&1 || true

          # PM2
          command -v pm2 >/dev/null 2>&1 || npm install -g pm2 >/dev/null 2>&1 || true

          # Ecosystem
          cat > ecosystem.config.cjs << 'EOFPM2'
module.exports = {
  apps: [{
    name: "astrowax-main",
    script: "npm",
    args: "start",
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: "1G",
    env: {
      NODE_ENV: "production",
      PORT: 6767
    }
  }]
};
EOFPM2

          pm2 delete astrowax-main 2>/dev/null || true
          pm2 delete AstroWax-Panel 2>/dev/null || true
          pm2 start ecosystem.config.cjs
          pm2 save --force 2>/dev/null || true

          echo "STARTED" > /tmp/awp-migrate-done.txt
        `;

        exec(swapCmd, { timeout: 120000 }, (err2, stdout2, stderr2) => {
          if (err2) {
            log.error("[migrate] Swap failed:", stderr2 || err2.message);
          } else {
            log.info("[migrate] v1.80 started");
          }

          // Delete v1.0 files
          setTimeout(async () => {
            try {
              await fs.remove(path.join(HOME, "AstroWax-Panel"));
              log.info("[migrate] Old v1.0 files removed");
            } catch (e) {
              log.warn("[migrate] Could not remove v1.0:", e.message);
            }
          }, 5000);
        });
      }, 800);
    });
  } catch (err) {
    log.error("[migrate] Fatal:", err);
    res.status(500).json({ error: "Migration failed", details: err.message });
  }
});

module.exports = router;