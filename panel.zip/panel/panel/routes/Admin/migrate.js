/*
 *  AstroWax Panel — Migration Route (v1.0 → v1.80)
 *  Auto-installs migrate.js during V1.0 panel install
 */

const express = require("express");
const router = express.Router();
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs-extra");
const os = require("os");

// ═══════════════════════════════════════════════════════════════
//  Auth middleware — checks all possible session locations
// ═══════════════════════════════════════════════════════════════
function requireAdmin(req, res, next) {
  console.log("[migrate] ========================================");
  console.log("[migrate] Endpoint hit!");
  console.log("[migrate] req.user:", req.user ? "present" : "null");
  console.log("[migrate] req.session?.user:", req.session?.user ? "present" : "null");
  console.log("[migrate] req.session?.passport:", req.session?.passport ? "present" : "null");

  // Try all possible auth locations
  const user =
    req.user ||
    req.session?.user ||
    req.session?.passport?.user ||
    req.session?.passportUser ||
    req.session?.account;

  if (user) {
    const role = user.role || user.userRole || user.type || user.accountRole;
    console.log("[migrate] User role:", role);

    if (role && role !== "admin" && role !== "owner") {
      return res.status(403).json({ error: "Admin access required (role: " + role + ")" });
    }
    console.log("[migrate] ✓ Authorized (has user + valid role)");
    return next();
  }

  // No user object — but if session exists, allow (they reached admin panel)
  if (req.session && Object.keys(req.session).length > 0) {
    console.log("[migrate] ✓ Authorized (session exists, admin panel access)");
    return next();
  }

  // No session at all — deny
  console.log("[migrate] ✗ Denied (no session)");
  return res.status(403).json({ error: "Admin access required (no session)" });
}

// ═══════════════════════════════════════════════════════════════
//  POST /api/admin/migrate-to-v180
// ═══════════════════════════════════════════════════════════════
router.post("/api/admin/migrate-to-v180", requireAdmin, async (req, res) => {
  const HOME = os.homedir();
  const v180Dir = path.join(HOME, "astrowax-v180");
  const v180PanelDir = path.join(v180Dir, "panel", "astrowax-panel");
  const v1PanelDir = process.cwd();
  const backupDir = path.join(HOME, "astrowax-v1-backup-" + Date.now());

  console.log("[migrate] Starting migration");
  console.log("[migrate] From:", v1PanelDir);
  console.log("[migrate] To:  ", v180PanelDir);

  try {
    // ─── STEP 1: Backup v1.0 data ───
    await fs.ensureDir(backupDir);
    const itemsToBackup = [
      "data", "config.json", ".env", "storage",
      "database.sqlite", "users.json", "sessions.db"
    ];
    for (const item of itemsToBackup) {
      const src = path.join(v1PanelDir, item);
      if (await fs.pathExists(src)) {
        await fs.copy(src, path.join(backupDir, item));
        console.log("[migrate] Backed up:", item);
      }
    }

    // ─── STEP 2: Install v1.80 ───
    const installCmd = `
      set -e
      export DEBIAN_FRONTEND=noninteractive

      # Node 20 via nvm
      export NVM_DIR="\${HOME}/.nvm"
      [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
      [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
      command -v nvm >/dev/null 2>&1 || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
      [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
      nvm install 20 >/dev/null 2>&1 || true
      nvm use 20 >/dev/null 2>&1 || true

      # Prepare target dir
      rm -rf "${v180Dir}"
      mkdir -p "${v180Dir}"
      cd "${v180Dir}"

      # Download panel.zip
      curl -fsSL "https://github.com/AstroVoidHostDev/astrowax/raw/main/panel.zip" -o panel.zip
      unzip -oq panel.zip
      rm -f panel.zip

      # Locate panel dir
      if [ -d "${v180PanelDir}" ]; then cd "${v180PanelDir}"
      elif [ -d "${v180Dir}/panel" ]; then cd "${v180Dir}/panel"
      else echo "PANEL_DIR_NOT_FOUND"; exit 1; fi

      # Restore v1.0 data
      mkdir -p .data
      [ -d "${backupDir}/data" ] && cp -r "${backupDir}/data/"* .data/ 2>/dev/null || true
      [ -f "${backupDir}/users.json" ] && cp "${backupDir}/users.json" .data/users.json 2>/dev/null || true
      [ -f "${backupDir}/database.sqlite" ] && cp "${backupDir}/database.sqlite" .data/database.sqlite 2>/dev/null || true
      [ -f "${backupDir}/.env" ] && cp "${backupDir}/.env" .env

      # Ensure .env has essential vars
      [ -f .env ] || echo "PORT=6767" > .env
      grep -q "^PORT=" .env || echo "PORT=6767" >> .env
      grep -q "^JWT_SECRET=" .env || echo "JWT_SECRET=\$(head -c 32 /dev/urandom | base64)" >> .env

      # Install deps
      echo "legacy-peer-deps=true" > .npmrc
      rm -rf node_modules package-lock.json
      npm cache clean --force >/dev/null 2>&1 || true
      npm install --legacy-peer-deps --no-audit --no-fund >/dev/null 2>&1

      # Build
      NODE_OPTIONS="--max-old-space-size=2048" npm run build >/dev/null 2>&1

      # Verify
      [ -f dist/server.cjs ] || { echo "BUILD_FAILED"; exit 1; }
      echo "INSTALL_OK"
    `;

    exec(installCmd, { timeout: 900000, maxBuffer: 50 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err || !stdout.includes("INSTALL_OK")) {
        console.error("[migrate] Install failed:", (stderr || err?.message || "").slice(-500));
        return res.status(500).json({
          error: "Installation failed",
          details: (stderr || err?.message || stdout || "").slice(-500),
        });
      }

      console.log("[migrate] v1.80 installed successfully");

      // ─── Respond first, then swap processes ───
      res.json({
        success: true,
        message: "Migration complete. Panel is restarting to v1.80...",
        v180Dir: v180PanelDir,
        backupDir,
      });

      // ─── STEP 3: Kill v1.0 + start v1.80 ───
      setTimeout(() => {
        const swapCmd = `
          # Kill running v1.0
          pkill -f "node .*AstroWax-Panel" 2>/dev/null || true
          sleep 2

          # Go to v1.80
          cd "${v180PanelDir}"

          # Node 20
          export NVM_DIR="\${HOME}/.nvm"
          [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
          [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
          nvm use 20 >/dev/null 2>&1 || true

          # PM2
          command -v pm2 >/dev/null 2>&1 || npm install -g pm2 >/dev/null 2>&1 || true

          # Ecosystem config
          cat > ecosystem.config.cjs << 'EOFPM2'
module.exports = {
  apps: [{
    name: "astrowax-main",
    script: "npm",
    args: "start",
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: "1G",
    env: {
      NODE_ENV: "production",
      PORT: 6767
    }
  }]
};
EOFPM2

          # Start v1.80
          pm2 delete astrowax-main 2>/dev/null || true
          pm2 delete AstroWax-Panel 2>/dev/null || true
          pm2 start ecosystem.config.cjs
          pm2 save --force 2>/dev/null || true

          echo "STARTED" > /tmp/awp-migrate-done.txt
        `;

        exec(swapCmd, { timeout: 180000 }, (err2, stdout2, stderr2) => {
          if (err2) {
            console.error("[migrate] Swap failed:", (stderr2 || err2.message).slice(-500));
          } else {
            console.log("[migrate] v1.80 started via PM2");
          }

          // ─── STEP 4: Delete old v1.0 files (after grace period) ───
          setTimeout(async () => {
            try {
              await fs.remove(path.join(HOME, "AstroWax-Panel"));
              console.log("[migrate] Old v1.0 files deleted");
            } catch (e) {
              console.warn("[migrate] Could not remove old files:", e.message);
            }
          }, 8000);
        });
      }, 1000);
    });

  } catch (err) {
    console.error("[migrate] Fatal:", err);
    res.status(500).json({ error: "Migration failed", details: err.message });
  }
});

module.exports = router;