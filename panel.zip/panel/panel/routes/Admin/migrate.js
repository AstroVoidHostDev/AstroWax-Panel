const express = require("express");
const router = express.Router();
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs-extra");
const os = require("os");

const migrationState = {
  running: false,
  step: "idle",
  message: "Ready",
  progress: 0,
  error: null,
  v180Dir: null,
  startedAt: null,
  finishedAt: null,
};

function resetState() {
  migrationState.running = false;
  migrationState.step = "idle";
  migrationState.message = "Ready";
  migrationState.progress = 0;
  migrationState.error = null;
  migrationState.v180Dir = null;
  migrationState.startedAt = null;
  migrationState.finishedAt = null;
}

function requireAdmin(req, res, next) {
  const user = req.user || req.session?.user || req.session?.passport?.user || req.session?.passportUser || req.session?.account;
  if (user) {
    const role = user.role || user.userRole || user.type || user.accountRole;
    if (role && role !== "admin" && role !== "owner") {
      return res.status(403).json({ error: "Admin access required" });
    }
    return next();
  }
  if (req.session && Object.keys(req.session).length > 0) return next();
  return res.status(403).json({ error: "Admin access required" });
}

// ═══════════════════════════════════════════════════════════════
//  SAFE BACKUP — copies files without crashing on missing/locked
// ═══════════════════════════════════════════════════════════════
async function safeBackupFile(src, dest) {
  try {
    const stats = await fs.lstat(src).catch(() => null);
    if (!stats) return false;

    // If it's a directory, recursively copy each file
    if (stats.isDirectory()) {
      await fs.ensureDir(dest);
      const entries = await fs.readdir(src).catch(() => []);
      for (const entry of entries) {
        // Skip SQLite journal/wal/shm files
        if (entry.endsWith("-journal") || entry.endsWith("-wal") || entry.endsWith("-shm")) {
          continue;
        }
        await safeBackupFile(path.join(src, entry), path.join(dest, entry));
      }
      return true;
    }

    // It's a file — check once, then copy
    const fileStats = await fs.stat(src).catch(() => null);
    if (!fileStats) return false;

    await fs.ensureDir(path.dirname(dest));
    await fs.copyFile(src, dest);
    return true;
  } catch (err) {
    // Silently skip — file might have been deleted during copy
    console.warn(`[migrate] Skipped ${path.basename(src)}: ${err.message}`);
    return false;
  }
}

// ═══════════════════════════════════════════════════════════════
//  POST /start
// ═══════════════════════════════════════════════════════════════
router.post("/api/admin/migrate-to-v180/start", requireAdmin, async (req, res) => {
  if (migrationState.running) {
    return res.json({ success: false, message: "Already running", state: migrationState });
  }

  resetState();
  migrationState.running = true;
  migrationState.step = "backup";
  migrationState.message = "Starting migration...";
  migrationState.progress = 5;
  migrationState.startedAt = Date.now();

  res.json({ success: true, message: "Started", state: migrationState });

  const HOME = os.homedir();
  const v180Dir = path.join(HOME, "astrowax-v180");
  const v1PanelDir = process.cwd();
  const backupDir = path.join(HOME, "astrowax-v1-backup-" + Date.now());

  console.log("[migrate] From:", v1PanelDir);
  console.log("[migrate] To:  ", v180Dir);
  console.log("[migrate] Backup:", backupDir);

  try {
    // ─── STEP 1: SAFE Backup ───
    migrationState.message = "Backing up v1.0 data...";
    migrationState.progress = 10;

    await fs.ensureDir(backupDir);

    const itemsToBackup = [
      "data",
      "config.json",
      ".env",
      "storage",
      "database.sqlite",
      "users.json",
      "sessions.db",
    ];

    for (const item of itemsToBackup) {
      const src = path.join(v1PanelDir, item);
      const dest = path.join(backupDir, item);
      const ok = await safeBackupFile(src, dest);
      if (ok) {
        console.log("[migrate] Backed up:", item);
      } else {
        console.log("[migrate] Skipped (not found or empty):", item);
      }
    }

    console.log("[migrate] Backup step complete");

    // ─── STEP 2: Install v1.80 ───
    migrationState.step = "install";
    migrationState.message = "Downloading v1.80...";
    migrationState.progress = 20;

    const installCmd = `
      set -e
      export DEBIAN_FRONTEND=noninteractive

      export NVM_DIR="\${HOME}/.nvm"
      [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
      [ -f "\$NVM_DIR/nvm.sh" ] || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
      . "\$NVM_DIR/nvm.sh"
      nvm install 20
      nvm use 20

      rm -rf "${v180Dir}"
      mkdir -p "${v180Dir}"
      cd "${v180Dir}"

      curl -fsSL "https://github.com/AstroVoidHostDev/astrowax/raw/main/panel.zip" -o panel.zip
      unzip -oq panel.zip
      rm -f panel.zip

      PANEL_JSON=\$(find "${v180Dir}" -maxdepth 6 -name "package.json" -not -path "*/node_modules/*" 2>/dev/null | head -1)
      [ -z "\$PANEL_JSON" ] && { echo "PANEL_NOT_FOUND"; exit 1; }
      cd "\$(dirname "\$PANEL_JSON")"
      echo "PANEL_DIR=\$(pwd)"

      mkdir -p .data
      [ -d "${backupDir}/data" ] && cp -r "${backupDir}/data/"* .data/ 2>/dev/null || true
      [ -f "${backupDir}/users.json" ] && cp "${backupDir}/users.json" .data/users.json 2>/dev/null || true
      [ -f "${backupDir}/.env" ] && cp "${backupDir}/.env" .env

      [ -f .env ] || echo "PORT=6767" > .env
      grep -q "^PORT=" .env || echo "PORT=6767" >> .env
      grep -q "^JWT_SECRET=" .env || echo "JWT_SECRET=\$(head -c 32 /dev/urandom | base64)" >> .env

      echo "legacy-peer-deps=true" > .npmrc
      rm -rf node_modules package-lock.json
      npm cache clean --force >/dev/null 2>&1 || true
      npm install --legacy-peer-deps --no-audit --no-fund
      NODE_OPTIONS="--max-old-space-size=2048" npm run build
      [ -f dist/server.cjs ] || { echo "BUILD_FAILED"; exit 1; }
      echo "FINAL_DIR=\$(pwd)"
      echo "INSTALL_OK"
    `;

    exec(installCmd, {
      timeout: 900000,
      maxBuffer: 50 * 1024 * 1024,
      env: { ...process.env, HOME: os.homedir() }
    }, async (err, stdout, stderr) => {
      if (err || !stdout.includes("INSTALL_OK")) {
        migrationState.running = false;
        migrationState.step = "error";
        migrationState.message = "Installation failed";
        migrationState.error = (stderr || err?.message || stdout || "").slice(-1000);
        console.error("[migrate] Install failed:", migrationState.error);
        return;
      }

      const match = stdout.match(/FINAL_DIR=(.+)/);
      const actualPanelDir = match ? match[1].trim() : path.join(v180Dir, "panel", "panel", "astrowax-panel");

      console.log("[migrate] Installed at:", actualPanelDir);
      migrationState.v180Dir = actualPanelDir;
      migrationState.step = "start";
      migrationState.message = "Starting v1.80 panel...";
      migrationState.progress = 85;

      // Write ecosystem config
      try {
        const ecosystemConfig = 'module.exports = {\n' +
          '  apps: [{\n' +
          '    name: "astrowax-main",\n' +
          '    script: "npm",\n' +
          '    args: "start",\n' +
          '    instances: 1,\n' +
          '    autorestart: true,\n' +
          '    watch: false,\n' +
          '    max_memory_restart: "1G",\n' +
          '    env: { NODE_ENV: "production", PORT: 6767 }\n' +
          '  }]\n' +
          '};\n';
        await fs.writeFile(path.join(actualPanelDir, "ecosystem.config.cjs"), ecosystemConfig);
        console.log("[migrate] ecosystem.config.cjs written");
      } catch (e) {
        console.error("[migrate] Failed to write ecosystem:", e.message);
      }

      // ─── STEP 3: Start v1.80 via PM2 ───
      const swapCmd = 'pm2 delete AstroWax-Panel 2>/dev/null || true; ' +
        'pm2 delete astrowax-main 2>/dev/null || true; ' +
        'sleep 1; ' +
        'cd "' + actualPanelDir + '"; ' +
        'export NVM_DIR="${HOME}/.nvm"; ' +
        '[ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm; ' +
        '. "$NVM_DIR/nvm.sh"; ' +
        'nvm use 20 >/dev/null 2>&1 || true; ' +
        'command -v pm2 >/dev/null 2>&1 || npm install -g pm2 >/dev/null 2>&1 || true; ' +
        'pm2 start ecosystem.config.cjs; ' +
        'pm2 save --force 2>/dev/null || true; ' +
        'for i in $(seq 1 30); do ' +
        '  if curl -s -f "http://127.0.0.1:6767/" >/dev/null 2>&1; then echo "PORT_UP"; break; fi; ' +
        '  sleep 2; ' +
        'done';

      exec(swapCmd, {
        timeout: 180000,
        shell: "/bin/bash",
        env: { ...process.env, HOME: os.homedir() }
      }, async (err2, stdout2, stderr2) => {
        console.log("[migrate] Swap output:", stdout2);
        console.log("[migrate] Swap errors:", stderr2);

        if (err2) {
          migrationState.running = false;
          migrationState.step = "error";
          migrationState.message = "Failed to start v1.80";
          migrationState.error = (stderr2 || err2.message).slice(-500);
          console.error("[migrate] Swap failed:", migrationState.error);
          return;
        }

        console.log("[migrate] v1.80 started successfully");
        migrationState.running = false;
        migrationState.step = "done";
        migrationState.message = "Migration complete! Redirecting to v1.80...";
        migrationState.progress = 100;
        migrationState.finishedAt = Date.now();

        // Kill old v1.0 AFTER browser redirects (delayed)
        setTimeout(() => {
          console.log("[migrate] Killing old v1.0 process...");
          try {
            exec('pkill -f "AstroWax-Panel/panel/panel/index.js" 2>/dev/null || true');
          } catch (e) {}
        }, 8000);

        // Clean old files
        setTimeout(async () => {
          try {
            await fs.remove(path.join(HOME, "AstroWax-Panel"));
            console.log("[migrate] Old v1.0 files deleted");
          } catch (e) {
            console.warn("[migrate] Could not remove v1.0:", e.message);
          }
        }, 15000);
      });
    });

  } catch (err) {
    console.error("[migrate] Fatal:", err);
    migrationState.running = false;
    migrationState.step = "error";
    migrationState.message = "Migration failed";
    migrationState.error = err.message;
  }
});

// ═══════════════════════════════════════════════════════════════
//  GET /status
// ═══════════════════════════════════════════════════════════════
router.get("/api/admin/migrate-to-v180/status", requireAdmin, (req, res) => {
  res.json(migrationState);
});

// ═══════════════════════════════════════════════════════════════
//  POST /reset
// ═══════════════════════════════════════════════════════════════
router.post("/api/admin/migrate-to-v180/reset", requireAdmin, (req, res) => {
  resetState();
  res.json({ success: true, message: "Reset", state: migrationState });
});

module.exports = router;