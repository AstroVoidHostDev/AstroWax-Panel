const express = require("express");
const router = express.Router();
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs-extra");
const os = require("os");

// ═══════════════════════════════════════════════════════════════
//  Global state (in-memory migration status)
// ═══════════════════════════════════════════════════════════════
const migrationState = {
  running: false,
  step: "idle",           // idle, backup, install, deps, build, start, done, error
  message: "Ready",
  progress: 0,
  error: null,
  v180Dir: null,
  startedAt: null,
  finishedAt: null,
};

function resetState() {
  migrationState.running = false;
  migrationState.step = "idle";
  migrationState.message = "Ready";
  migrationState.progress = 0;
  migrationState.error = null;
  migrationState.v180Dir = null;
  migrationState.startedAt = null;
  migrationState.finishedAt = null;
}

// ═══════════════════════════════════════════════════════════════
//  Auth middleware
// ═══════════════════════════════════════════════════════════════
function requireAdmin(req, res, next) {
  const user = req.user || req.session?.user || req.session?.passport?.user || req.session?.passportUser || req.session?.account;
  if (user) {
    const role = user.role || user.userRole || user.type || user.accountRole;
    if (role && role !== "admin" && role !== "owner") {
      return res.status(403).json({ error: "Admin access required" });
    }
    return next();
  }
  if (req.session && Object.keys(req.session).length > 0) return next();
  return res.status(403).json({ error: "Admin access required" });
}

// ═══════════════════════════════════════════════════════════════
//  POST /start — Immediately responds, runs install in background
// ═══════════════════════════════════════════════════════════════
router.post("/api/admin/migrate-to-v180/start", requireAdmin, async (req, res) => {
  if (migrationState.running) {
    return res.json({
      success: false,
      message: "Migration already running",
      state: migrationState
    });
  }

  resetState();
  migrationState.running = true;
  migrationState.step = "backup";
  migrationState.message = "Starting migration...";
  migrationState.progress = 5;
  migrationState.startedAt = Date.now();

  // ─── Respond IMMEDIATELY ───
  res.json({
    success: true,
    message: "Migration started",
    state: migrationState
  });

  // ─── Run migration in background ───
  const HOME = os.homedir();
  const v180Dir = path.join(HOME, "astrowax-v180");
  const v1PanelDir = process.cwd();
  const backupDir = path.join(HOME, "astrowax-v1-backup-" + Date.now());

  console.log("[migrate] Starting background migration");

  try {
    // ─── Backup ───
    migrationState.message = "Backing up v1.0 data...";
    migrationState.progress = 10;

    await fs.ensureDir(backupDir);
    for (const item of ["data", "config.json", ".env", "storage", "database.sqlite", "users.json", "sessions.db"]) {
      const src = path.join(v1PanelDir, item);
      if (await fs.pathExists(src)) {
        await fs.copy(src, path.join(backupDir, item));
      }
    }

    migrationState.step = "install";
    migrationState.message = "Downloading v1.80...";
    migrationState.progress = 20;

    // ─── Install Command ───
    const installCmd = `
      set -e
      export DEBIAN_FRONTEND=noninteractive

      export NVM_DIR="\${HOME}/.nvm"
      [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
      if [ ! -f "\$NVM_DIR/nvm.sh" ]; then
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
      fi
      . "\$NVM_DIR/nvm.sh"
      nvm install 20
      nvm use 20
      echo "NODE_VERSION=\$(node -v)"

      rm -rf "${v180Dir}"
      mkdir -p "${v180Dir}"
      cd "${v180Dir}"

      curl -fsSL "https://github.com/AstroVoidHostDev/astrowax/raw/main/panel.zip" -o panel.zip
      echo "DOWNLOADED=\$(ls -la panel.zip | awk '{print \$5}')"
      unzip -oq panel.zip
      rm -f panel.zip

      PANEL_JSON=\$(find "${v180Dir}" -maxdepth 6 -name "package.json" -not -path "*/node_modules/*" 2>/dev/null | head -1)
      [ -z "\$PANEL_JSON" ] && { echo "PANEL_NOT_FOUND"; exit 1; }
      PANEL_FOUND_DIR=\$(dirname "\$PANEL_JSON")
      cd "\$PANEL_FOUND_DIR"
      echo "PANEL_DIR=\$(pwd)"

      mkdir -p .data
      [ -d "${backupDir}/data" ] && cp -r "${backupDir}/data/"* .data/ 2>/dev/null || true
      [ -f "${backupDir}/users.json" ] && cp "${backupDir}/users.json" .data/users.json 2>/dev/null || true
      [ -f "${backupDir}/.env" ] && cp "${backupDir}/.env" .env

      [ -f .env ] || echo "PORT=6767" > .env
      grep -q "^PORT=" .env || echo "PORT=6767" >> .env
      grep -q "^JWT_SECRET=" .env || echo "JWT_SECRET=\$(head -c 32 /dev/urandom | base64)" >> .env

      echo "legacy-peer-deps=true" > .npmrc
      rm -rf node_modules package-lock.json
      npm cache clean --force >/dev/null 2>&1 || true
      npm install --legacy-peer-deps --no-audit --no-fund
      echo "DEPS_INSTALLED"

      NODE_OPTIONS="--max-old-space-size=2048" npm run build
      echo "BUILD_DONE"

      [ -f dist/server.cjs ] || { echo "MISSING_SERVER"; exit 1; }
      echo "FINAL_DIR=\$(pwd)"
      echo "INSTALL_OK"
    `;

    exec(installCmd, {
      timeout: 900000,
      maxBuffer: 50 * 1024 * 1024,
      env: { ...process.env, HOME: os.homedir() }
    }, async (err, stdout, stderr) => {
      if (err || !stdout.includes("INSTALL_OK")) {
        migrationState.running = false;
        migrationState.step = "error";
        migrationState.message = "Installation failed";
        migrationState.error = (stderr || err?.message || stdout || "").slice(-1000);
        console.error("[migrate] Install failed:", migrationState.error);
        return;
      }

      const match = stdout.match(/FINAL_DIR=(.+)/);
      const actualPanelDir = match ? match[1].trim() : path.join(v180Dir, "panel", "panel", "astrowax-panel");

      console.log("[migrate] Installed at:", actualPanelDir);
      migrationState.v180Dir = actualPanelDir;
      migrationState.step = "start";
      migrationState.message = "Starting v1.80 panel...";
      migrationState.progress = 85;

      // ─── Start v1.80 via PM2 ───
      const swapCmd = `
        pkill -f "node .*AstroWax-Panel" 2>/dev/null || true
        sleep 2
        cd "${actualPanelDir}"
        export NVM_DIR="\${HOME}/.nvm"
        [ -s "/usr/local/share/nvm/nvm.sh" ] && export NVM_DIR=/usr/local/share/nvm
        [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"
        nvm use 20 >/dev/null 2>&1 || true
        command -v pm2 >/dev/null 2>&1 || npm install -g pm2 >/dev/null 2>&1 || true

        cat > ecosystem.config.cjs << 'EOFPM2'
module.exports = {
  apps: [{
    name: "astrowax-main",
    script: "npm",
    args: "start",
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: "1G",
    env: { NODE_ENV: "production", PORT: 6767 }
  }]
};
EOFPM2

        pm2 delete astrowax-main 2>/dev/null || true
        pm2 delete AstroWax-Panel 2>/dev/null || true
        pm2 start ecosystem.config.cjs
        pm2 save --force 2>/dev/null || true

        # Wait for port 6767
        for i in \$(seq 1 30); do
          if curl -s -f "http://127.0.0.1:6767/" >/dev/null 2>&1; then
            echo "PORT_UP"
            break
          fi
          sleep 2
        done
      `;

      exec(swapCmd, { timeout: 180000, env: { ...process.env, HOME: os.homedir() } }, async (err2, stdout2, stderr2) => {
        if (err2) {
          migrationState.running = false;
          migrationState.step = "error";
          migrationState.message = "Failed to start v1.80";
          migrationState.error = (stderr2 || err2.message).slice(-500);
          return;
        }

        console.log("[migrate] v1.80 started");
        migrationState.running = false;
        migrationState.step = "done";
        migrationState.message = "Migration complete! Redirecting...";
        migrationState.progress = 100;
        migrationState.finishedAt = Date.now();

        // ─── Delete old v1.0 files after 10 sec ───
        setTimeout(async () => {
          try {
            await fs.remove(path.join(HOME, "AstroWax-Panel"));
            console.log("[migrate] Old v1.0 files removed");
          } catch (e) {}
        }, 10000);
      });
    });

  } catch (err) {
    console.error("[migrate] Fatal:", err);
    migrationState.running = false;
    migrationState.step = "error";
    migrationState.message = "Migration failed";
    migrationState.error = err.message;
  }
});

// ═══════════════════════════════════════════════════════════════
//  GET /status — Browser polls this for progress
// ═══════════════════════════════════════════════════════════════
router.get("/api/admin/migrate-to-v180/status", requireAdmin, (req, res) => {
  res.json(migrationState);
});

// ═══════════════════════════════════════════════════════════════
//  POST /reset — Reset state (if stuck)
// ═══════════════════════════════════════════════════════════════
router.post("/api/admin/migrate-to-v180/reset", requireAdmin, (req, res) => {
  resetState();
  res.json({ success: true, message: "State reset", state: migrationState });
});

module.exports = router;