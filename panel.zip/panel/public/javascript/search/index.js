// DOM Elements
const searchModal = document.getElementById('searchModal');
const modalContent = document.querySelector('.modal-content');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const navLinks = document.querySelectorAll('.nav-link');

// State
let selectedIndex = -1;
let filteredLinks = [];

// Helper: Filter and display links based on search term
function filterLinks(searchTerm) {
  // Split the search term into mainTerm and subTerm
  const [mainTerm, subTerm] = searchTerm.split(':/');

  // Normalize terms for comparison
  const mainTermFiltered = mainTerm?.toLowerCase() || '';
  const subTermFiltered = subTerm?.toLowerCase() || '';

  // Filter links
  filteredLinks = Array.from(navLinks).filter((link) => {
    const textContent = link.textContent.toLowerCase();
    const searchData = link.getAttribute('searchdata')?.toLowerCase();
    const linkSubTerm = link.getAttribute('subterm')?.toLowerCase();

    // Check main term match
    const mainTermMatch =
      textContent.includes(mainTermFiltered) ||
      (searchData && searchData.includes(mainTermFiltered));

    // Check sub term match (if exists)
    const subTermMatch = !subTermFiltered ||
      textContent.includes(subTermFiltered) ||
      (searchData && searchData.includes(subTermFiltered)) ||
      (linkSubTerm && linkSubTerm.includes(subTermFiltered));

    return mainTermMatch && subTermMatch;
  });

  // Render results
  renderResults();
}

// Helper: Render filtered results
function renderResults() {
  searchResults.innerHTML = '';

  if (filteredLinks.length === 0) {
    const noResultsMessage = document.createElement('p');
    noResultsMessage.textContent = 'No results found.';
    noResultsMessage.classList.add('text-gray-400', 'text-sm', 'mt-4');
    searchResults.appendChild(noResultsMessage);
    selectedIndex = -1;
    return;
  }

  filteredLinks.forEach((link, index) => {
    const resultLink = document.createElement('a');
    resultLink.href = link.href;
    resultLink.textContent = link.textContent;
    resultLink.classList.add(
      'nav-link',
      'transition',
      'text-gray-600',
      'hover:bg-gray-200',
      'backdrop-blur',
      'hover:text-gray-800',
      'group',
      'flex',
      'items-center',
      'px-4',
      'py-2',
      'text-sm',
      'font-medium',
      'rounded-xl',
      'mt-1'
    );

    if (index === 0) {
      resultLink.classList.add('bg-gray-200', 'text-gray-900', 'font-semibold', 'searchLinkActive');
      selectedIndex = 0;
    }

    resultLink.setAttribute('role', 'option');
    resultLink.setAttribute('aria-selected', index === selectedIndex ? 'true' : 'false');
    resultLink.tabIndex = 0;

    resultLink.addEventListener('mouseenter', () => {
      updateSelected(index);
    });

    resultLink.addEventListener('click', (e) => {
      if (index === selectedIndex) {
        e.preventDefault();
        window.location.href = resultLink.href;
      }
    });

    searchResults.appendChild(resultLink);
  });
}

// Helper: Update selected index and UI
function updateSelected(newIndex) {
  if (newIndex < 0 || newIndex >= filteredLinks.length) return;

  // Remove active class from previous selection
  const prevSelected = searchResults.querySelector('.searchLinkActive');
  if (prevSelected) {
    prevSelected.classList.remove('bg-gray-200', 'text-gray-900', 'font-semibold', 'searchLinkActive');
    prevSelected.setAttribute('aria-selected', 'false');
  }

  // Add active class to new selection
  const newSelected = searchResults.children[newIndex];
  if (newSelected) {
    newSelected.classList.add('bg-gray-200', 'text-gray-900', 'font-semibold', 'searchLinkActive');
    newSelected.setAttribute('aria-selected', 'true');
    selectedIndex = newIndex;
  }
}

// Show search modal
function showSearchResults() {
  searchModal.classList.add('show');
  setTimeout(() => {
    modalContent.classList.add('visible');
    searchInput.focus();
    searchInput.value = '';
    filterLinks('');
  }, 10);
}

// Event Listeners
document.addEventListener('keydown', (event) => {
  // Open modal with Ctrl+K / Cmd+K
  if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
    event.preventDefault();
    showSearchResults();
  }

  // Close modal with Escape
  if (event.key === 'Escape') {
    modalContent.classList.remove('visible');
    setTimeout(() => {
      searchModal.classList.remove('show');
    }, 300);
  }

  // Handle arrow keys for navigation
  if (searchModal.classList.contains('show')) {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      updateSelected(selectedIndex + 1);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      updateSelected(selectedIndex - 1);
    } else if (event.key === 'Enter' && selectedIndex >= 0) {
      event.preventDefault();
      const selectedLink = searchResults.querySelector('.searchLinkActive');
      if (selectedLink) {
        window.location.href = selectedLink.href;
      }
    }
  }
});

// Close modal when clicking outside
window.addEventListener('click', (event) => {
  if (event.target === searchModal) {
    modalContent.classList.remove('visible');
    setTimeout(() => {
      searchModal.classList.remove('show');
    }, 300);
  }
});

// Filter on input
searchInput.addEventListener('input', () => {
  const searchTerm = searchInput.value;
  filterLinks(searchTerm);
});

// Initialize
filterLinks('');